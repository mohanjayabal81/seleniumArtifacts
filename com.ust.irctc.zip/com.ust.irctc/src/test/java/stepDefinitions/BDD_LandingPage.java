package stepDefinitions;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BDD_LandingPage {
	
	WebDriver driver;
	@Given("Open the page with Chrome Browser")
	public void open_the_page_with_chrome_browser() {
		driver = new ChromeDriver();
	    System.out.println("This is the code1");
	}

	@When("I navigate the page url")
	public void i_navigate_the_page_url() {
		System.out.println("This is the code2");
		driver.get("https://petstore.octoperf.com/");
	}

	@Then("I validate the Page title")
	public void i_validate_the_page_title() {
		System.out.println("This is the code3");  
		String title = driver.getTitle();
		System.out.println(title);
	}

	@Then("I validate the Page URL")
	public void i_validate_the_page_url() {
		System.out.println("This is the code4");
		String URL = driver.getCurrentUrl();
		System.out.println(URL);
	}

	@Then("I validate the Welcome Text")
	public void i_validate_the_welcome_text() {
		System.out.println("This is the code5"); 
	}

	@Then("I validate the copyright message")
	public void i_validate_the_copyright_message() {
		System.out.println("This is the code6");
	}

	@Then("I validate the Enter the store link")
	public void i_validate_the_enter_the_store_link() throws InterruptedException {
		System.out.println("This is the code7"); 
		driver.findElement(By.linkText("Enter the Store")).click();
		Thread.sleep(2000);
	}

	@Then("Click on the link check outcomes")
	public void click_on_the_link_check_outcomes() {
		
	     boolean result = driver.findElement(By.linkText("Sign In")).isDisplayed();
	     assertTrue(false);
	     
	}

}
