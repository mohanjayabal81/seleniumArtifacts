package baseClasspages;

public class LoginPage {

}
